package com.example.showcase.ui.gallery;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.showcase.R;
import com.example.showcase.databinding.FragmentGalleryBinding;

import java.util.Random;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;
    private EditText adj1EditText, adj2EditText, verb1EditText, noun1EditText, noun2EditText, animalEditText, nameEditText, verb2EditText;
    private TextView resultTextView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize UI components
        adj1EditText = root.findViewById(R.id.adj1);
        adj2EditText = root.findViewById(R.id.adj2);
        verb1EditText = root.findViewById(R.id.verb1);
        noun1EditText = root.findViewById(R.id.noun1);
        noun2EditText = root.findViewById(R.id.noun2);
        animalEditText = root.findViewById(R.id.animal);
        nameEditText = root.findViewById(R.id.name);
        verb2EditText = root.findViewById(R.id.verb2);
        resultTextView = root.findViewById(R.id.titleTextView);

        Button madlib1Button = root.findViewById(R.id.madlib1BTN);
        Button madlib2Button = root.findViewById(R.id.madlib2BTN);
        Button madlib3Button = root.findViewById(R.id.madlib3BTN);
        Button randomButton = root.findViewById(R.id.randomBTN);

        madlib1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String madLib = generateMadLib("Once upon a time, there was a " +
                        adj1EditText.getText().toString() + " " +
                        noun1EditText.getText().toString() + " who loved to " +
                        verb1EditText.getText().toString() + ". " +
                        "One day, they met a " + adj2EditText.getText().toString() + " " +
                        noun2EditText.getText().toString() + " named " +
                        nameEditText.getText().toString() + ". " +
                        nameEditText.getText().toString() + " was known for their ability to " +
                        verb2EditText.getText().toString() + " with a " +
                        animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
                resultTextView.setMaxLines(10); // Set an appropriate maximum number of lines
                resultTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); // Set an appropriate size


            }
        });

        madlib2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String madLib = generateMadLib("In a far-off land, there lived a " +
                        adj1EditText.getText().toString() + " " +
                        noun1EditText.getText().toString() + " who had a passion for " +
                        verb1EditText.getText().toString() + ". " +
                        "One sunny morning, they encountered a " + adj2EditText.getText().toString() + " " +
                        noun2EditText.getText().toString() + " by the name of " +
                        nameEditText.getText().toString() + ". " +
                        nameEditText.getText().toString() + " was renowned for their ability to " +
                        verb2EditText.getText().toString() + " alongside a friendly " +
                        animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
                resultTextView.setMaxLines(10); // Set an appropriate maximum number of lines
                resultTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); // Set an appropriate size



            }
        });

        madlib3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String madLib = generateMadLib("In a remote corner of the universe, there flew a " +
                        adj1EditText.getText().toString() + " " +
                        noun1EditText.getText().toString() + " that was on a mission to " +
                        verb1EditText.getText().toString() + ". " +
                        "One fateful night, they encountered a " + adj2EditText.getText().toString() + " " +
                        noun2EditText.getText().toString() + " named " +
                        nameEditText.getText().toString() + ". " +
                        nameEditText.getText().toString() + " was renowned for their ability to " +
                        verb2EditText.getText().toString() + " alongside a curious " +
                        animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
                resultTextView.setMaxLines(10); // Set an appropriate maximum number of lines
                resultTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); // Set an appropriate size


            }
        });

        randomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button[] madlibButtons = {madlib1Button, madlib2Button, madlib3Button};
                Random random = new Random();
                int randomIndex = random.nextInt(madlibButtons.length);
                Button selectedButton = madlibButtons[randomIndex];
                selectedButton.performClick();
            }
        });

        return root;
    }

    private String generateMadLib(String story) {
        return story;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
