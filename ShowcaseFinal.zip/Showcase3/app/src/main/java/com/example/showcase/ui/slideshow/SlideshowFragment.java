package com.example.showcase.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.showcase.R;
import com.example.showcase.databinding.FragmentSlideshowBinding;

import java.util.Random;

public class SlideshowFragment extends Fragment {

    private FragmentSlideshowBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SlideshowViewModel slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        EditText firstETXT = root.findViewById(R.id.firstEditText);
        EditText lastETXT = root.findViewById(R.id.lastEditText);
        EditText cityETXT = root.findViewById(R.id.cityEditText);
        EditText schoolETXT = root.findViewById(R.id.schoolEditText);
        EditText petETXT = root.findViewById(R.id.petEditText);
        EditText siblingETXT = root.findViewById(R.id.siblingEditText);
        Button generateBTN = root.findViewById(R.id.generateButton);
        TextView outputTXT = root.findViewById(R.id.outputTextView);

        generateBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Generates random numbers for string manipulation
                Random randy = new Random();
                // Retrieves values from EditText components
                String firstName = String.valueOf(firstETXT.getText());
                String lastName = String.valueOf(lastETXT.getText());
                String city = String.valueOf(cityETXT.getText());
                String school = String.valueOf(schoolETXT.getText());
                String petName = String.valueOf(petETXT.getText());
                String siblingName = String.valueOf(siblingETXT.getText());
                // Generates the sci-fi names by combining substrings based on random portions
                int firstPortion = randy.nextInt(firstName.length());
                int lastPortion = randy.nextInt(lastName.length());
                String sciFiFirstName = firstName.substring(0, firstPortion) + lastName.substring(0, lastPortion);
                firstPortion = randy.nextInt(city.length());
                lastPortion = randy.nextInt(school.length());
                String sciFiLastName = city.substring(0, firstPortion) + school.substring(0, lastPortion);
                firstPortion = randy.nextInt(petName.length());
                lastPortion = randy.nextInt(siblingName.length());
                String sciFiOrigin = firstName.substring(0, firstPortion) + lastName.substring(0, lastPortion);
                outputTXT.setText(sciFiFirstName + " " + sciFiLastName + " of the planet " + sciFiOrigin); // Displays the generated sci-fi name
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
