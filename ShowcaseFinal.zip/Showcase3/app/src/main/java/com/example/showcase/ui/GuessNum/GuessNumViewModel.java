package com.example.showcase.ui.GuessNum;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GuessNumViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public GuessNumViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is gan fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}