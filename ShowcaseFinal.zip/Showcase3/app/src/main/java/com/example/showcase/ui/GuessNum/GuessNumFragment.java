package com.example.showcase.ui.GuessNum;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.showcase.R;
import com.example.showcase.databinding.FragmentGanBinding;

import java.util.Random;

public class GuessNumFragment extends Fragment {
    private int secretNumber;
    private int strikes;
    private int points;
    private TextView resultTextView;
    private EditText guessEditText;
    private Button guessButton;
    private FragmentGanBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        GuessNumViewModel GuessNumViewModel = new ViewModelProvider(this).get(GuessNumViewModel.class);

        binding = FragmentGanBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize UI elements
        resultTextView = root.findViewById(R.id.resultTextView);
        guessEditText = root.findViewById(R.id.guessEditText);
        guessButton = root.findViewById(R.id.guessButton);

        // Generate the initial secret number
        generateSecretNumber();

        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the user's guess
                if (!guessEditText.getText().toString().isEmpty()) {
                    int userGuess = Integer.parseInt(guessEditText.getText().toString());

                    // Check the guess
                    boolean isCorrect = checker(userGuess);

                    // Update UI based on the score
                    if (isCorrect) {
                        resultTextView.setText("You got it! Points: " + points);
                        generateSecretNumber();
                        strikes = 0;
                        points += 50;
                    } else {
                        strikes++;
                        resultTextView.setText("Incorrect! Strikes: " + strikes);

                        // Check for game over
                        if (strikes == 10) {
                            resultTextView.setText("Game over! You've reached 10 strikes. Points: " + points);
                            generateSecretNumber();
                            strikes = 0;
                            points = 0; // Resets the points if you lose

                            // Show custom toast for game over
                            showCustomToast("Game Over! Try again.");
                        }
                    }
                } else {
                    resultTextView.setText("Please enter a guess!");
                }
            }
        });
        return root;
    }

    private void generateSecretNumber() {
        Random randy = new Random();
        secretNumber =  randy.nextInt(100) + 1; // Generates a random number between 1 and 100
    }

    private boolean checker(int userGuess) {
        if (userGuess < secretNumber) {
            // Displays this message if the number is too low
            return false;
        } else if (userGuess > secretNumber) {
            // Displays this message if the number is too high
            return false;
        } else {
            // Displays this message if the number is correct
            return true;
        }
    }

    private void showCustomToast(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
