package com.example.madlibfinaljava;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText adj1EditText, adj2EditText, verb1EditText, noun1EditText, noun2EditText, animalEditText, nameEditText, verb2EditText;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        adj1EditText = findViewById(R.id.adj1);
        adj2EditText = findViewById(R.id.adj2);
        verb1EditText = findViewById(R.id.verb1);
        noun1EditText = findViewById(R.id.noun1);
        noun2EditText = findViewById(R.id.noun2);
        animalEditText = findViewById(R.id.animal);
        nameEditText = findViewById(R.id.name);
        verb2EditText = findViewById(R.id.verb2);
        resultTextView = findViewById(R.id.titleTextView);
        // Find and initialize buttons by their IDs

        Button madlib1Button = findViewById(R.id.madlib1BTN);
        Button madlib2Button = findViewById(R.id.madlib2BTN);
        Button madlib3Button = findViewById(R.id.madlib3BTN);
        Button randomButton = findViewById(R.id.randomBTN);

        madlib1Button.setOnClickListener(new View.OnClickListener() {               // Set click listeners for the "madlib" buttons

            @Override
            public void onClick(View view) {
                String madLib = generateMadLib(                          // Create a Mad Lib story using user input and set it in the resultTextView

                        "Once upon a time, there was a " + adj1EditText.getText().toString() + " " +
                                noun1EditText.getText().toString() + " who loved to " + verb1EditText.getText().toString() + ". " + // concatonate    all the nouns and adverbs with the madlib  its paired with each button
                                "One day, they met a " + adj2EditText.getText().toString() + " " +
                                noun2EditText.getText().toString() + " named " + nameEditText.getText().toString() + ". " +
                                nameEditText.getText().toString() + " was known for their ability to " +
                                verb2EditText.getText().toString() + " with a " + animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
            }
        });

        madlib2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String madLib = generateMadLib(
                        "In a far-off land, there lived a " + adj1EditText.getText().toString() + " " +
                                noun1EditText.getText().toString() + " who had a passion for " + verb1EditText.getText().toString() + ". " +
                                "One sunny morning, they encountered a " + adj2EditText.getText().toString() + " " +
                                noun2EditText.getText().toString() + " by the name of " + nameEditText.getText().toString() + ". " +
                                nameEditText.getText().toString() + " was renowned for their ability to " +
                                verb2EditText.getText().toString() + " alongside a friendly " + animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
            }
        });

        madlib3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String madLib = generateMadLib(
                        "In a remote corner of the universe, there flew a " + adj1EditText.getText().toString() + " " +
                                noun1EditText.getText().toString() + " that was on a mission to " + verb1EditText.getText().toString() + ". " +
                                "One fateful night, they encountered a " + adj2EditText.getText().toString() + " " +
                                noun2EditText.getText().toString() + " named " + nameEditText.getText().toString() + ". " +
                                nameEditText.getText().toString() + " was renowned for their ability to " +
                                verb2EditText.getText().toString() + " alongside a curious " + animalEditText.getText().toString() + ".");
                resultTextView.setText(madLib);
            }
        });
        // Similar click listeners for madlib2Button and madlib3Button

        // Set a click listener for the "random" button

        randomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button[] madlibButtons = {madlib1Button, madlib2Button, madlib3Button};
                Random random = new Random();
                int randomIndex = random.nextInt(madlibButtons.length);
                Button selectedButton = madlibButtons[randomIndex];
                selectedButton.performClick();
            }
        });
    }
    // This method generates and returns the Mad Lib story

    private String generateMadLib(String story) {
        return story;
    }
}
